//
//  dbconnection.h
//  FEMS
//
//  Created by contus on 04/09/13.
//  Copyright (c) 2013 contus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "sqlite3.h"
#define DBName @"firstdb.sqlite"
@interface dbconnection : NSObject
{
    sqlite3 *database;
	NSString *documentsPath;
	NSString *documentsDir;
	NSString *databaseName;
    
    BOOL result;
    NSMutableDictionary *dict;
    NSMutableArray *dictArray;
    NSUserDefaults *userCurrentStatus;
    
}


-(void)verifyDatabase:(NSString *)dbName:(NSString *)dbPath;

-(void)openDatabase;

-(BOOL)updateCheckedin:(NSString*)jid:(int)deleteValue;
//-(NSMutableDictionary *)getRecords:(NSString*)jid;
-(NSMutableArray *)selectallRecords;
//-(BOOL)deleteallRecords;
-(NSMutableArray *)getallRecords;
//-(BOOL)insernewRecords:(NSMutableArray*)records;
@end
