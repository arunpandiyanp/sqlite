//
//  dbconnection.m
//  FEMS
//
//  Created by contus on 04/09/13.
//  Copyright (c) 2013 contus. All rights reserved.
//

#import "dbconnection.h"

@implementation dbconnection

-(void)verifyDatabase:(NSString *)dbName:(NSString *)dbPath {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:dbPath])
    {
        NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:databaseName];
        [fileManager copyItemAtPath:databasePathFromApp toPath:dbPath error:nil];
         NSLog(@"documentsPath %@ - %@",dbPath,databasePathFromApp);
    }
    //[fileManager release];
}

-(void)openDatabase
{
    databaseName = DBName;
    documentsDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex: 0];
    NSLog(@"%@",documentsDir);
    documentsPath = [documentsDir stringByAppendingPathComponent:databaseName];
    NSLog(@"%@",documentsPath);
    [self verifyDatabase:databaseName:documentsPath];
    
}



/* Get the last message from the table based on userid */
-(NSMutableArray *)selectallRecords
{
    [self openDatabase];
    //NSLog(@"Last-%@",jid);
    dictArray = [[NSMutableArray alloc]init];
    
    if(sqlite3_open([documentsPath UTF8String], &database) == SQLITE_OK)
    {
        // Setup the SQL Statement and compile it for faster access
        const char *sqlStatement = nil;
     
        sqlStatement=[[NSString stringWithFormat:@"select * from student"]UTF8String];

        sqlite3_stmt *compiledStatement;
        //sqlite3_prepare(<#sqlite3 *db#>, <#const char *zSql#>, <#int nByte#>, <#sqlite3_stmt **ppStmt#>, <#const char **pzTail#>)
        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK)
        {
            // Loop through the results and add them to the feeds array
            while(sqlite3_step(compiledStatement) == SQLITE_ROW)
            {
                NSLog(@"DATA PRESENT");
                NSString *name = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
                NSString *rollno = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
				//NSString *tagValue = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
                //NSString *deleteValue = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
              
               // dict = [[NSMutableDictionary alloc]init];
                //[dict setObject:name forKey:@"name"];
                //[dict setObject:tagValue forKey:@"TAG"];
                //[dict setObject:deleteValue forKey:@"DELETE"];
                [dictArray addObject:name];
                [dictArray addObject:rollno];
                //NSLog(@"Last-%@",dict);
                //[dictArray addObject:dict];
                
            }
        }
        else
        {
            NSLog(@"Failed");
            NSLog(@"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
        }
        sqlite3_finalize(compiledStatement);
    }
    sqlite3_close(database);
    NSLog(@"dict-Arra-%@",dictArray);
    return dictArray;
    
}

/* Get the last message from the table based on userid */
-(NSMutableArray *)getallRecords
{
    [self openDatabase];
    //NSLog(@"Last-%@",jid);
    dictArray = [[NSMutableArray alloc]init];
    if(sqlite3_open([documentsPath UTF8String], &database) == SQLITE_OK)
    {
        // Setup the SQL Statement and compile it for faster access
        const char *sqlStatement = nil;
        
        sqlStatement=[[NSString stringWithFormat:@"select deleteValue from helpsettings_table"]UTF8String];
        
        sqlite3_stmt *compiledStatement;
        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK)
        {
            // Loop through the results and add them to the feeds array
            while(sqlite3_step(compiledStatement) == SQLITE_ROW)
            {
                NSLog(@"DATA PRESENT");
                NSString *name = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
				//NSString *tagValue = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
                //NSString *deleteValue = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
                
                 dict = [[NSMutableDictionary alloc]init];
                //[dict setObject:name forKey:@"name"];
                [dict setObject:name forKey:@"delete"];
                //[dict setObject:deleteValue forKey:@"DELETE"];
                //[dictArray addObject:name];
                //NSLog(@"Last-%@",dict);
                [dictArray addObject:dict];
                
            }
        }
        else
        {
            NSLog(@"Failed");
            NSLog(@"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
        }
        sqlite3_finalize(compiledStatement);
    }
    sqlite3_close(database);
    NSLog(@"dict-Arra-%@",dictArray);
    return dictArray;

}

-(BOOL)updateCheckedin:(NSString*)jid:(int)deleteValue
{
    
    [self openDatabase];
    //BOOL result;
    const char *sqlStatement = nil;
    
    sqlStatement =[[NSString stringWithFormat:@"update helpsettings_table set deleteValue = %d where id = '%@'",deleteValue,jid] UTF8String];
//    NSLog(@"%@",[NSString stringWithFormat:@"update helpsettings_table set deleteValue = %d where id = '%@'",deleteValue,jid]);
    
    
    if(sqlite3_open([documentsPath UTF8String], &database) == SQLITE_OK)
    {
        if (sqlite3_exec(database, sqlStatement, NULL,NULL, NULL) == SQLITE_OK)
        {
            NSLog(@"Updated");
            result = YES;
        }
        else
        {
            NSLog(@"Failed");
            NSLog(@"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
            result = NO;
        }
    }
    sqlite3_close(database);
    return result;
    
}




@end
