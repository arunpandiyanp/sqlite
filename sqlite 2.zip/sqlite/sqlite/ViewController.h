//
//  ViewController.h
//  sqlite
//
//  Created by Dinesh Jaganathan on 18/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
        obj *object=[[obj alloc]init];
        
    
}
@end

