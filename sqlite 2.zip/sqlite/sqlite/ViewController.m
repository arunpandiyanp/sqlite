//
//  ViewController.m
//  sqlite
//
//  Created by Dinesh Jaganathan on 18/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "object1.h"
#import "dbconnection.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    object1 *obj=[[object1 alloc]init];
    [ obj click];
    [obj call:@"Hellohai"];
    //NSLog(@"%@",[obj call]);
    dbconnection *object=[[dbconnection alloc]init];
    [object openDatabase];
    [object selectallRecords];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)hai
{
        NSLog(@"hai");
}

@end
