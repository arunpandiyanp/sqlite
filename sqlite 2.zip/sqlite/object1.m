//
//  object1.m
//  sqlite
//
//  Created by Dinesh Jaganathan on 18/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "object1.h"

@implementation object1
-(void)click
{
    NSLog(@"hello");
    
}
-(NSString*)call:(NSString*) str
{
NSString *st=@"good";
    NSLog(@"%@",str);
    
    return st;
}
@end
