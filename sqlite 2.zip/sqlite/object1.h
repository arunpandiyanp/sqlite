//
//  object1.h
//  sqlite
//
//  Created by Dinesh Jaganathan on 18/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface object1 : NSObject
{
    
}
-(void)click;
-(NSString*)call:(NSString*) str;
@end
